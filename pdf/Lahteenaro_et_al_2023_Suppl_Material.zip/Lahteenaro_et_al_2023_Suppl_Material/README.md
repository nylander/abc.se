# Supplementary Material, Lähteenaro et al., 2023.

<https://doi.org/10.1111/syen.12618>

## Files

- `syen12618-sup-0001-FigureS1.pdf` PDF document, 710.1 KB

Figure S1: Maximum likelihood tree including long branches that were removed
from downstream analyses. All nodes were maximally (100) supported by ultrafast
bootstrap except those denoted with coloured circles. The scale bar indicates
the expected number of substitutions per site. Terminal labels contain the
following information separated by underscores: Voucher code, Stylops species,
Host species (Andrena), sampling country in ISO 3166-1 alpha-2 abbreviation
code and the host subgenus.

- `syen12618-sup-0002-FigureS2.pdf` PDF document, 458.9 KB

Figure S2: Lineage-through-time plot of ultrametric tree used for the GMYC
analysis. The maximum likelihood solution is indicated with a red line and the
2-log likelihood confidence interval is denoted by a blue area.

- `syen12618-sup-0003-TableS1.xlsx` Excel 2007 spreadsheet , 23.9 KB

Table S1: List of studied material.
