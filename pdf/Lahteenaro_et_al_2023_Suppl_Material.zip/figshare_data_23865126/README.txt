# General information

Source:

https://figshare.scilifelab.se/articles/dataset/Phylogenomic_species_delimitation_of_the_twisted-winged_parasite_genus_i_Stylops_i_Strepsiptera_/23865126

Authors:

Meri Lähteenaro
Jakub Straka
Mattias Forshage
Rasmus Hovmöller
Yuta Nakase
Anders L. Nilsson
John T. Smit
Johan A. A. Nylander
Johannes Bergsten

Author ORCIDs:

Meri Lähteenaro https://orcid.org/0000-0001-9868-3134
Jakub Straka https://orcid.org/0000-0002-8987-1245
Rasmus Hovmöller https://orcid.org/0009-0008-3232-7944
Yuta Nakase https://orcid.org/0000-0001-5925-4564
John T. Smit https://orcid.org/0000-0002-1568-5183
Johan Nylander https://orcid.org/0000-0001-8940-456X
Johannes Bergsten https://orcid.org/0000-0002-6153-4431

Contact e-mail: meri.lahteenaro@nrm.se

DOI: 10.17044/scilifelab.23865126

This readme file was last updated: 2023-12-15

Please cite as:

Lähteenaro, M., Forshage, M., Hovmöller, R., Nakase, Y., Nilsson, A. L.,
Nylander, J. A. A., Smit, J. T., Straka, J. & Bergsten, J. (2023). Phylogenomic
species delimitation of the twisted-winged parasite genus Stylops
(Strepsiptera). SciLifeLab. Dataset.
https://doi.org/10.17044/scilifelab.23865126

# Dataset description

This is a repository for files from the study: Phylogenomic species
delimitation of the twisted-winged parasite genus Stylops (Strepsiptera).

We obtained genomic data by whole-genome sequencing from 163 Stylops females in
order to test conflicting species hypothesis in Western Palaearctic region. We
used the included 2315 orthologous loci to infer species tree and maximum
likelihood tree. 

Data set contains:

'MSA_stylops.zip': MSAs of the 2315 orthologous genes used for phylogenetic
inferences and species delimitation

'ASTRAL_stylops.treefile': Inferred species tree from ASTRAL

'ML_stylops.treefile': Inferred maximum likelihood tree from IQ-TREE2. Terminal
labels in the tree files contain the following information separated by
underscores: Voucher code, Stylops species, Host species (Andrena), sampling
country in ISO 3166-1 alpha-2 abbreviation code and the host subgenus.
