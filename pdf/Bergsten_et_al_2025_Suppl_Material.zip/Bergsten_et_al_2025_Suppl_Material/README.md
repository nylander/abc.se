Bergsten, J., Nylander, J.A.A., Ospina, O.E., Lemmon, A.R. & Miller, K.B.
(2025) Whole genome shotgun phylogenomics resolve the diving beetle tree of
life. Systematic Entomology, 1–35. Available from:
https://doi.org/10.1111/syen.12685


DATA AVAILABILITY STATEMENT

Raw data for new taxa in the form of untrimmed reads in FastQ format is made
available at the European Nucleotide Archive (ENA) (accession numbers in Table
S1). The concatenated dataset (aligned and trimmed) in fasta format, a
partition file defining the separate genes and a gene code translation table
are made available at SciLifeLab data repository
https://www.scilifelab.se/data/repository/ powered by Figshare. DOI number for
collection of files: https://doi.org/10.17044/scilifelab.28868468.v1.


SUPPORTING INFORMATION

Figure S1. Concatenated Maximum likelihood tree based on all loci (5364).
Values at nodes are ultrafast bootstrap values (UFB)(* if 100)/gene concordance
factor (gCF).

Figure S2. Concatenated Maximum likelihood tree without Hyderodes shuckardi
(long-branch extraction). Node values are local SH-like support values from
FastTreeMP.

Figure S3. Concatenated Maximum likelihood tree without Notaticus fasciatus
(long-branch extraction). Node values are local SH-like support values from
FastTreeMP.

Figure S4. Four-cluster likelihood mapping of the basal ingroup trichotomy when
genes are ranked by either occupancy (a) or phylogenetic informativeness (b)
and increasing portions (0, 10, 25, 50, 75 90%) excluded.

Figure S5. Four-cluster likelihood mapping of the Copelatinae position when
genes are ranked by either occupancy (a) or phylogenetic informativeness (b)
and increasing portions (0, 10, 25, 50, 75 90%) excluded.

Figure S6. Four-cluster likelihood mapping of the Hyderodes problem when genes
are ranked by either occupancy (a) or phylogenetic informativeness (b) and
increasing portions (0, 10, 25, 50, 75 90%) excluded.

Figure S7. Four-cluster likelihood mapping of the Notaticus problem when genes
are ranked by either occupancy (a) or phylogenetic informativeness (b) and
increasing portions (0, 10, 25, 50, 75 90%) excluded.

Figure S8. ASTRAL tree based on dataset nounique (3202 loci).

Figure S9. ASTRAL tree based on dataset common3 (1529 loci).

Figure S10. ASTRAL tree based on dataset common4 (369 loci).

Figure S11. Concatenated maximum likelihood tree based on dataset nounique
(3202 loci).

Figure S12. Concatenated maximum likelihood tree based on dataset common3 (1529
loci).

Figure S13. Concatenated maximum likelihood tree based on dataset common4 (369
loci).

Figure S14. ASTRAL tree based on all loci (5364) where 54 taxa from
Vasilikopoulos et al. (2021) are excluded.

Figure S15. ASTRAL tree based on dataset nounique (3202 loci) where 54 taxa
from Vasilikopoulos et al. (2021) are excluded.

Figure S16. ASTRAL tree based on dataset common3 (1529 loci) where 54 taxa from
Vasilikopoulos et al. (2021) are excluded.

Figure S17. Concatenated maximum likelihood tree based on all loci (5364) where
54 taxa from Vasilikopoulos et al. (2021) are excluded.

Figure S18. Concatenated maximum likelihood tree based on dataset nounique
(3202 loci) where 54 taxa from Vasilikopoulos et al. (2021) are excluded.

Figure S19. Concatenated maximum likelihood tree based on dataset common3 (1529
loci) where 54 taxa from Vasilikopoulos et al. (2021) are excluded.

Figure S20. ASTRAL tree based on reference clade-based gene filtering.

Figure S21. ASTRAL tree based on all 5364 loci but Pachydrus sp. is excluded.

Table S1. Metadata on included specimens.

Table S2. Statistics of per taxon locus occupancy in full dataset and three
reduced datasets as well as per taxon BUSCO statistics for newly sequenced
taxa. C = Complete genes, S = Single Copy Complete Genes, D=Duplicated Complete
Genes, F = Fragmented Genes, subclass 1: only a portion of the gene is present
in the assembly, and the rest of the gene cannot be aligned. I=Fragmented
Genes, subclass 2: a section of the gene aligns to one position in the
assembly, while the remaining part aligns to another position, M = Missing
Genes, N = number of BUSCO reference genes.
